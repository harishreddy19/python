class Queue:
    def __init__(self,size):
        self.q = []
        self.size = size

    def enqueue(self,ele):
        if len(self.q) == self.size:
            print("Queue Overflow")
        else :
            self.q.append(ele)
    
    def dequeue(self):
        if self.q == []:
            print("Queue Underflow")
        else :
            k = self.q.pop(0)
            print(f"Popped element : {k}")
        
    def display(self):
        if self.q == []:
            print("Queue Underflow")
        else :
            print('Elements of the Queue')
            print(self.q)
            
n = int(input('Enter the size of the Queue :'))
q = Queue(n)
while(True):
    print('**Queue Imolimentation**')
    print('Enter any Operation')
    print('1.enqueue')
    print('2.dequeue')
    print('3.display')
    print('4.Exit')
    op = int(input())
    if op == 1:
        k = input("Enter the element to push :")
        q.enqueue(k)
    elif op == 2:
        q.dequeue()
    elif op == 3:
        q.display()
    else :
        print('Invalid input...1please give a valid input')
        break
print('\n\n')
