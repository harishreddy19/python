class Node:
    def __init__(self,data):
        self.data = data
        self.next = None
#Creating a new Singly list class 
class SinglyLL:
    def __init__(self):
        self.head = None
        self.tail = None
#method for checking is the list is empty or not 
    def isEmpty(self):
        if self.head is None:
            return True
        else :
            return False
    # MEthod to insert the element at the begging 
    def  insert_at_begin(self,data):
        nb = Node(data)
        if self.isEmpty():
            self.head  = nb
            self.tail = nb
        else :
            nb.next = self.head
            self.head = nb
        self.count=1

#method to insert a node at the end 
    def insert_at_end(self,data):
        ne = Node(13)
        if self.isEmpty():
            self.head = ne
            self.tail = ne
        else :
            temp = self.head
            while temp.next is not None :
                temp = temp.next
            temp.next = ne
        self.count+=1
# Method to insert at the spcefied position in the liked list
    def insert_at_pos(self,data):
        npos = Node(data)
        temp = self.head
        print(f"Enter at which postion to insert between 1 to {self.count+1}")
        pos = int(input())
        if self.isEmpty():
            print('Linked list  is Empty')
        elif pos == 1:
            self.insert_at_begin(data)
        else:
            for i in range(1,pos-1):
                temp = temp.next
            npos.next = temp.next
            temp.next = npos
            self.count+=1
#delete a node at the beggging in the linked list
    def delete_at_begin(self):
        if self.isEmpty():
            print("List is Empty")
        else :
            temp = self.head
            self.head = temp.next
            #temp.next =None
#method to delete at the End of the linked list
    def delete_at_end(self):
        temp = self.head.next
        prev = self.head
        if self.isEmpty():
            print("List is Empty")
        while temp.next is not None:
            temp = temp.next
            prev = prev.next
        prev.next = None

#method to delete the node at specfied location
    def delete_at_pos(self):
        if self.isEmpty():
            print("List is Empty")
        else :
            temp = self.head.next
            prev = self.head
            print(f"Enter at which postion to delete the Node between 1 to {self.count-1}")
            pos = int(input())
            if pos == 1:
                self.delete_at_begin()
            else :
                for i in range(1,pos-1):
                    temp = temp.next
                    prev = prev.next
                prev.next = temp.next
                temp.next = None
#method to display the elements of the linked list
    def display(self):
        temp = self.head
        while temp !=None:
            print(temp.data,'-->',end='')
            temp =temp.next 
        print()



sl = SinglyLL()
n = Node(10)
sl.head = n
sl.display()
sl.insert_at_begin(12)
print("After inserting at the Begin")
sl.display()
sl.insert_at_end(29)
print("After inserting at the End")
sl.display()
sl.insert_at_pos(40)
print("After inserting at spcefied position")
sl.display()
sl.delete_at_begin()
print("After deleting at the begin")
sl.display()
sl.delete_at_end()
print("After deleting at the End")
sl.display()
sl.delete_at_pos()
print("After deleting at the spcefied postion ")
sl.display()