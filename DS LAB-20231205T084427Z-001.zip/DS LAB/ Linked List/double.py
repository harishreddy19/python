class Node:
    def __init__(self,data):
        self.data = data
        self.next = None
        self.prev = None
class DoubleLL:
    def __init__(self):
        self.head = None
        self.tail = None
        self.count = 0
# To Check wether the is Empty or not
    def isEmpty(self):
        if self.head == None:
            return True
        else :
            return False
# Method to insert the node at the begin
    def insert_at_begin(self,data):
        nb = Node(data)
        if self.isEmpty():
            self.head = nb
            self.tail = nb
        else :
            nb.next = self.head
            self.head.prev = nb
            self.head  = nb
        self.count+=1
# method for inserting the node at the End
    def insert_at_end(self,data):
        ne = Node(data)
        if self.isEmpty():
            self.head = ne
            self.tail = ne
        else :
            temp = self.head
            while temp.next is not None:
                temp = temp.next
            ne.prev = temp
            temp.next = ne
        self.count+=1
# method to insert the node at specfied postion
    def insert_at_pos(self,data):
        npos = Node(data)
        if self.isEmpty():
            print("List is Empty")
        else :
            temp = self.head
            print(f"Enter at which postion to insert the Node between 1 to {self.count+1}")
            pos = int(input())
            if pos ==1:
                self.insert_at_begin(data)
            else:
                for i in range(1,pos-1):
                    temp =temp.next
                npos.next = temp.next
                npos.prev = temp
                temp.next = npos
                temp.next.prev = npos
            self.count+=1
#method to delete the Node at the Ebeggning of the list
    def delete_at_begin(self):
        if self.isEmpty():
            print("List is empty")
        else :
            temp  =self.head
            self.head = temp.next
            temp.next = None
            self.head.prev = None
            self.count-=1
# method to delete the Node at the End
    def delete_at_end(self):
        if self.isEmpty():
            print("List is Empty")
        else:
            temp = self.head.next
            previous = self.head
            while temp.next is not None :
                temp =temp.next
                previous= previous.next
            previous.next = None
            self.count-=1
# method to delete the node at spcefied postion
    def delete_at_pos(self):
        if self.isEmpty():
            print("List is Empty")
        else :
            temp = self.head.next
            previous = self.head
            print(f"Enter at which postion to delete the Node between 1 to {self.count}")
            pos = int(input())
            if pos ==1:
                self.delete_at_begin()
            else :
                for i in range(1,pos-1):
                    temp = temp.next
                    previous = previous.next
                previous.next = temp.next
                temp.next.prev = previous
                temp.prev = None
                temp.next = None
# Method to display the elements of the list
    def display(self):
        if self.isEmpty():
            print("List is Empty")
        else:
            temp = self.head
            while temp is not None:
                print(temp.data,'-->',end='')
                temp = temp.next
        print()


dl = DoubleLL() 
n = Node(0)
dl.head = n
dl.display()
dl.insert_at_begin(1)
print("After inserting at the begin")
dl.display()
dl.insert_at_end(3)
print("After inserting at the End")
dl.display()
dl.insert_at_pos(4)
print("After insetting at specfied postion ")
dl.display()
dl.delete_at_begin()
print("After deleting at the begin")
dl.display()
dl.delete_at_end()
print("After deleting at the End")
dl.display()
dl.delete_at_pos()
print("After deleting at specfied postion")
dl.display()           