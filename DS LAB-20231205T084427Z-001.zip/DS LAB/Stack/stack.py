class Stack1:
    def __init__(self, size):
        self.stk = []
        self.size = size

    def push_ele(self, ele):
        if len(self.stk) == self.size:
            print("***Stack Overflow***")
        else:
            self.stk.append(ele)

    def pop_ele(self):
        if self.stk == []:
            print("***Stack Underflow***")
        else:
            popped_element = self.stk.pop()
            print(f"Popped Element: {popped_element}")
            
    def peek(self):
        if self.stk == []:
            print("***Stack Underflow")
        else :
            print(self.stk[-1])

    def display(self):
        if self.stk == []:
            print("***Stack is empty***")
        else:
            print("Elements of the Stack:")
            print(self.stk[-1],'<--top')
            for i in range(len(self.stk)-2,-1,-1):
                    print(self.stk[i])

k = int(input("Enter the Size of the Stack: "))
s = Stack1(k)

while True:
    print('STACK IMPLEMENTATION')
    print("Enter any Operation")
    print('1. Push')
    print('2. Pop')
    print('3.Peek')
    print('4. Display')
    print('5. Exit')
    oper = int(input())
    
    if oper == 1:
        ele = input("Enter the element to push: ")
        s.push_ele(ele)
    elif oper == 2:
        s.pop_ele()
    elif oper == 3:
        s.peek()
    elif oper == 4:
        s.display()
    else :
        break
    print('\n\n')