class Methods:
    def __init__(self,name,model): # constructor
        self.name = name 
        self.model = model 
        
    # class Method with default argument
    @classmethod    
    def Mileage(cls,mileage = 50):
        print(f"Mileage is {mileage}")

    # Static Method
    @staticmethod
    def Speed(speed):
        print(f"Speed is : {speed} km/s")

    def Display(self):  # Method To display 
        print(f"Name : {self.name} Model : {self.model}")

m = Methods("Maruthi",2000)  # object 
m.Display()
m.Speed(300)   # Accessing the Static method
Methods.Mileage() # Accessing the Class method
        