class Local:
    #class variable
    com_name = "Dell"

    # creating constructor 
    def __init__(self,name,id): 
        self.name = name  # instance variable
        self.id = id

    # Method
    def Display(self): 
        print(f"Customer Name : {self.name} Customer Id : {self.id} Company Name : {Local.com_name}")

c = Local("John",435)  # Objects of the class
c1 = Local("Ramu",857)
print("Displaying the Customer Deatils")
c.Display() # accessing the Method through obj
print(c1.name)
print(Local.com_name)  #accessing the class variable through class Name
