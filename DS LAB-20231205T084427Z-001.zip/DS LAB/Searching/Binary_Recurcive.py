class BinarySearch:
    def __init__(self, list1, ele):
        self.list1 = list1
        self.ele = ele
        self.lower_bound = 0
        self.upper_bound = len(list1) - 1
        self.pos = -1  # Initialize pos here

    def search(self):
        while self.lower_bound <= self.upper_bound:
            mid = (self.lower_bound + self.upper_bound) // 2
            if self.list1[mid] == self.ele:
                self.pos = mid  # Update self.pos when the element is found
                return self.pos
            elif self.list1[mid] < self.ele:
                self.lower_bound = mid + 1
            else:
                self.upper_bound = mid - 1
        return self.pos  # Return self.pos if the element is not found

str_list = input("Enter the elements in ascending order separated by spaces: ").split()
list1 = [int(x) for x in str_list]
ele = int(input("Enter the element to search: "))
obj = BinarySearch(list1, ele)
pos = obj.search()
if pos == -1:
    print("Element not Found")
else:
    print(f"Element found at index {pos}")
