class LinearSerach:
    pos = -1
    def __init__(self,list1,ele):
        self.list1 = list1
        self.ele = ele
    def Search(self):
        for i in range(len(self.list1)):
            if self.ele == self.list1[i]:
                pos = i
                return pos
        return -1
str_list= input("Enter the elements saparated by the spaces :").split()
list1 = [int(x) for x in str_list]
ele =int(input("Enter the element to search in the list :"))
obj = LinearSerach(list1,ele)
pos = obj.Search()
if pos == -1 :
    print(f"Element not found")

else :
    print(f"Element found at index {pos}")
