class BinarySearch :
    pos = -1
    def __init__(self,list1,ele):
        self.list1 = list1
        self.ele = ele
    def Search(self):
        l = 0; h = len(self.list1)-1
        while l <= h:
            mid = (l+h)//2
            if self.ele == self.list1[mid]:
                self.pos = mid
                return self.pos
            elif self.ele < self.list1[mid]:
                h = mid -1
            else :
                l = mid +1 
        return self.pos

list1 = [int(x) for x in input("Enter the elements in assending order sapatated by spaces :").split()]
ele = int(input("Enter the element to search :"))
obj = BinarySearch(list1,ele)
pos = obj.Search()
if pos == -1 :
    print("The element is not found")
else :
    print(f"The element is found at index {pos}")