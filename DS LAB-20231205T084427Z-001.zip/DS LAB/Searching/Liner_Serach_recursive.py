class LinearSearch:
    pos = -1
    def __init__(self,list1,ele):
        self.list1 = []
        self.ele = ele
    def search(self):
        l = len(self.list1)
        for i in range(0,l-1):
            if self.list1[i] == self.ele:
                self.pos = i
                return self.pos
            i = i + 1
        return self.pos

str_list = input("Enter the elements saparated by the spaces :").split()
list1 = [int(x) for x in str_list]
ele = input("Enter the element to seaech :")
obj = LinearSearch(list1,ele)
pos = obj.search()
if pos == -1:
    print("The element is not found")
else:
    print(f"The element is found at index {pos}")
