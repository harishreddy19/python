class Operator:
    def __init__(self,m1,m2):
        self.m1 = m1
        self.m2 = m2
    def __add__(self,other):
        return self.m1+other.m1 + self.m2+other.m2
    def __sub__(self,other):
        return self.m1+other.m1 - self.m2+other.m2
    def __gt__(self,other):
        return self.m1+other.m1 > self.m1+other.m2
    
obj1 = Operator(12,31)
obj2 = Operator(13,36)
print(f"Addition of 2 objects : {obj1+obj2}")
print(f"Substraction of 2 objects : {obj1-obj2}")
