class addition:
    def __init__(self, m1, m2):
        self.m1 = m1
        self.m2 = m2

    def sum(self, a=None, b=None, c=None):
        if a != None and b != None and c != None:
            print(f"Sum : {a + b + c}")
        elif a != None and b != None:
            print(f"Sum :{a + b}")
        else:
            print(f"Sum :{a}")


a = addition(2, 3)
a.sum(2, 3)
a.sum(2, 3, 4, )