class Parent:
    def __init__(self):
        self.a = "IN Parent Class"
    def show(self):
        print(self.a)
class Child(Parent):
    def __init__(self):
        self.b = "In Child Class"
    def show(self):
        print(self.b)
p = Parent()
c = Child()
for x in (p,c):
    x.show()