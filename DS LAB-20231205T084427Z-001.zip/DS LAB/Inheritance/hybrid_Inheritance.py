#HYBRID INHERITANCE 

class University:    #University class Base Class
    def __init__(self,uname):
        self.uname = uname
    
    def Display(self):
        print("**From University Class**")
        print(f"University Name : {self.uname}")

'''Course class(Drived Class) Inherited from University class(Base Class)'''
class Course(University):  
     def __init__(self,uname,course):
         super().__init__(uname)
         self.course = course
    
     def Display(self):
         print("**From Course Class**")
         print(f"University Name : {self.uname}\nCourse Name : {self.course}")
        
'''Branch class(Drived Class) Inherited from Course class(Base Class)
        Multi-level Inheritancr'''
class Branch(Course):
    def __init__(self, uname, course,branch):
        super().__init__(uname, course)
        self.branch = branch

    def Display(self):
           print("**From Branch Class**")
           print(f"University Name : {self.uname}\nCourse Name : {self.course}\nBranch Name : {self.branch}")

'''Student class(Drived Class) Inherited from Branch and  Course class(Base Classes)
      multiple Inheritance'''
class Student(Branch,Course):
    def __init__(self, uname, course,branch,sname):
        super().__init__(uname, course,branch)
        self.sname = sname
    
    def Display(self):
          print("**From Student class**")
          print(f"University Name : {self.uname}\nCourse Name : {self.course}\nBranch Name : {self.branch}\nStudent Name : {self.sname}")

'''Faculty class(Drived Class) Inherited from Student class(Base Class)'''
class Faculty(Student):
     def __init__(self,uname,course,branch,sname,fname):
          super().__init__(uname,course,branch,sname)
          self.fname = fname
    
     def Display(self):
         print("**From Faculty class**")
         print(f"University Name : {self.uname}\nCourse Name : {self.course}\nBranch Name : {self.branch}\nStudent Name : {self.sname}\nFaculty Name : {self.fname}")

print("*****Student Details*****")
f = Faculty("XyZ","Engineering","CSE","Ramu","Santhosh")
f.Display()   # Accessing from the Faculty Class
print("\n")

#Accessing from the Student class
s = Student("ABC","BTECH","MECh","Laxman")
s.Display()