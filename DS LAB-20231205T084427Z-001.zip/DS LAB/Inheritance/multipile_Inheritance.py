class Father:
    def __init__(self, fname):
        self.fname = fname
    def Show1(self):
        print(f"Father Name : {self.fname}")
class Mother:
    def __init__(self, mname):
        self.mname = mname

    def Show2(self):
        print(f"Mother Name : {self.mname}")

class Child(Father,Mother):
    def __init__(self, fname, mname,name):
        Father.__init__(self, fname)
        Mother.__init__(self, mname)
        self.name = name

    def Show3(self):
        super().Show1()
        super().Show2()
        print(f"Child Name : {self.name}")

c = Child("Ramu","Laxmi","Raju")
c.Show3()