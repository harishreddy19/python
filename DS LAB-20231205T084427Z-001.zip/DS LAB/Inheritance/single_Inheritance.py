class Animal:
    def __init__(self,name,breed):
        self.name = name
        self.breed = breed
    def Walk(self):
        print("I can Walk")
    def Work(self,value):
        print(f"My name is {self.name} and My value is {value}")
class Dog(Animal):
    def __init__(self,name,age,breed):
        self.age = age
        super().__init__(name,breed)
    def eat(self):
        print("I cann Eat")

    def Info(self):
        print(f"My name is {self.name} and my breed is {self.breed} and {self.age}")
    def Run(self):
        print("I can run")
d = Dog("Puppy",54,"pu")
print(d.name)
print(d.age)
print(d.breed)
d.Info()
d.Work(6456)