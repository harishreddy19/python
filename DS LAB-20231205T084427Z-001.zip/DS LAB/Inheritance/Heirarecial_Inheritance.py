class Shape:
    def Area(self):
        pass
    def Perimeter(self):
        pass
class Triangle(Shape):
    def __init__(self,length,bredth):
        self.length=length
        self.bredth=bredth
    def Area(self):

        print(f"Area of Triangle : {0.5 * self.length * self.bredth}")
    def Perimeter(self):
        print(f"Perimeter of Triangle : {self.length + self.bredth}")
class Circle(Shape):
    def __init__(self,radius):
        self.radius=radius
    def Area(self):
        print(f"Area of Circle : {3.14 * self.radius**2}")
    def Perimeter(self):
        print(f"Perimeter of Circle : {2 * 3.14 * self.radius}")
c = Circle(6)
t = Triangle(4,6)
for x in (c,t):
    x.Area()
    x.Perimeter()