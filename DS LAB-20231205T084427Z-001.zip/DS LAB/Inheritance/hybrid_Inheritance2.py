class University:         # University class
    def __init__(self,uni_name):
        self.name = uni_name
    def UniverstyInfo(self):
        print(f"University Name : {self.name}")

class Course(University):    # Course class from University
    def __init__(self,uni_name,cou_name):
        self.cname = cou_name
        super().__init__(uni_name)
    def UniverstyInfo(self):
        print(f"University Name : {self.name} \n Course Name : {self.cname}")

class Branch(University):     # Branch class University
    def __init__(self,uni_name,cou_name,Branch_name):
        super().__init__(uni_name,cou_name)
        self.branch = Branch_name
    def UniverstyInfo(self):
        print(f"University Name : {self.name} \n Course Name : {self.cname} \n Branch Name : {self.branch}")

class Student(Course,Branch):   # Student class from Couse and Branch
    def __init__(self,uni_name,cou_name,Branch_name,stu_name):
        super().__init__(uni_name,cou_name,Branch_name)
        self.sname = stu_name
    def UniverstyInfo(self):
        print(f"University Name : {self.name} \n Course Name : {self.cname} \n Branch Name : {self.branch} \n Student Name : {self.sname}")

class Faculty(Branch):           # Faculty class from Branch
    def __init__(self,uni_name,cou_name,Branch_name,stu_name,fac_name):
        super().__init__(uni_name,cou_name,Branch_name,stu_name)
        self.fname = fac_name
    def UniverstyInfo(self):
        print(f"University Name : {self.name} \n Course Name : {self.cname} \n Branch Name : {self.branch} \n Student Name : {self.sname} \n Faculty Name : {self.fname}")
fac =Faculty("MALLA REDDY","ENGINEERING","CSE","Rajesh","Nirmala")
fac.UniverstyInfo(Faculty)





'''class University:
    def __init__(self,unname):
        self.uname = unname
    def Info(self):
        print(f"University Name : {self.uname}")
class Course(University):
    def __init__(self,uname,cname):
        self.cname = cname
        super().__init__(uname)
    def Info(self):
        print(f"University Name : {self.uname} \n Course Name : {self.cname}")
class Branch(University):
    def __init__(self,uname,bname):
        super().__init__(uname)
        #super().__init__(cname)
        self.bname = bname
    def Info(self):
        print(f"University Name : {self.uname} \n  Branch Name : {self.bname}")
class Student(Course,Branch):
    def __init__(self,uname,cname,bname,sname):
        super().__init__(uname,cname,bname)
        self.sname = sname

    def Info(self):
        print(f"University Name : {self.uname} \n Course Name : {self.cname} \n Branch Name : {self.bname} \n Student Name : {self.sname}")
class Faculty(Branch):
    def __init__(self):
d = Branch("MALLA REDDY",'ENGINEERING','CSE')
d.Info()
'''