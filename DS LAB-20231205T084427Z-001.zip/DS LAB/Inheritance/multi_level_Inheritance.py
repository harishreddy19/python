class Car:
    def __init__(self,tryes,glasses):
        self.tryes = tryes
        self.glasses = glasses
    def Speed(self):
        print("I can go speed")
    def Info(self):
        print(f"I Have {self.tryes} Tryes and {self.glasses} Glasses")
class BMW(Car):
    def __init__(self,name,tryes,glasses):
        super().__init__(tryes,glasses)
        self.name =  name
    def Colour(self,colour):
        print(f"My name {self.name} .My colour is {self.colour} Colour")
class Car_1(BMW) :
    def __init__(self,seats,name,tryes,glasses):
        super().__init__(name,tryes,glasses)
        self.seats = seats
    def Fast(self):
        print("I can go Fast")
class Car_2(Car_1):
    def __init__(self,ingine_name,seats,name,tryes,glasses):
        self.ingine = ingine_name
        super().__init__(seats,name,tryes,glasses)
    def Mileage(self):
        print(" MY mileage is 50km/l")
c = Car_2('464R',9,"Ford",4,6)
print(c.tryes)
print(c.ingine)
print(c.glasses)
c.Info()

